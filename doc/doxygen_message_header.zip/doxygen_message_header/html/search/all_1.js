var searchData=
[
  ['message_2ehpp_1',['message.hpp',['../message_8hpp.html',1,'']]],
  ['message_5ft_2',['message_t',['../structmessage__t.html',1,'message_t'],['../structmessage__t.html#a47bb91aed9d131f20af9f3e0941e93a6',1,'message_t::message_t()'],['../structmessage__t.html#a534114a2ec940fce60c0079abaa1ff8c',1,'message_t::message_t(float i_value)']]]
];
