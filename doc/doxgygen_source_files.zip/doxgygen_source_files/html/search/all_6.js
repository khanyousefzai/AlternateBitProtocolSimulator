var searchData=
[
  ['time_20',['TIME',['../main_8cpp.html#a3893724880e0bfd3cabf4fceb0d0fb5d',1,'main.cpp']]],
  ['time_5fstatistics_5ffile_21',['time_statistics_file',['../main_8cpp.html#a1931409c1ecea1caa6a079e6d4629bb8',1,'main.cpp']]]
];
