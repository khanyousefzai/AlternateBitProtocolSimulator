var searchData=
[
  ['time_5fadvance_71',['time_advance',['../class_receiver.html#aedb53af510b5eec9410a2c416d318e51',1,'Receiver::time_advance()'],['../class_sender.html#ae1b25557826618a8c9908aa1457cbc96',1,'Sender::time_advance()'],['../class_subnet.html#a660dd622ef74c7d4eddc51657943c230',1,'Subnet::time_advance()']]]
];
