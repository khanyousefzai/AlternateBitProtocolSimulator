var searchData=
[
  ['model_5factive_13',['model_active',['../struct_sender_1_1state__type.html#a3af2c15212fbaba7f41ef694cdc344f4',1,'Sender::state_type']]]
];
