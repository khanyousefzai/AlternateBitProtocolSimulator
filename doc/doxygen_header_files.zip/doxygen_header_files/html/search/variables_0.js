var searchData=
[
  ['ack_64',['ack',['../struct_sender_1_1state__type.html#aa7e19418506ec249ea947c9bf39558be',1,'Sender::state_type']]],
  ['ack_5fnum_65',['ack_num',['../struct_receiver_1_1state__type.html#ad4f666629f3c7dd68fb49808cc4e0611',1,'Receiver::state_type']]],
  ['alt_5fbit_66',['alt_bit',['../struct_sender_1_1state__type.html#a49f0d5c92128a17fe0c083fc9936de23',1,'Sender::state_type']]]
];
