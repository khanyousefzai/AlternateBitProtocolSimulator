var searchData=
[
  ['ackin_39',['ackIn',['../structsender__defs_1_1ack_in.html',1,'sender_defs']]],
  ['ackreceivedout_40',['ackReceivedOut',['../structsender__defs_1_1ack_received_out.html',1,'sender_defs']]]
];
