var searchData=
[
  ['ack_0',['ack',['../struct_sender_1_1state__type.html#aa7e19418506ec249ea947c9bf39558be',1,'Sender::state_type']]],
  ['ack_5fnum_1',['ack_num',['../struct_receiver_1_1state__type.html#ad4f666629f3c7dd68fb49808cc4e0611',1,'Receiver::state_type']]],
  ['ackin_2',['ackIn',['../structsender__defs_1_1ack_in.html',1,'sender_defs']]],
  ['ackreceivedout_3',['ackReceivedOut',['../structsender__defs_1_1ack_received_out.html',1,'sender_defs']]],
  ['alt_5fbit_4',['alt_bit',['../struct_sender_1_1state__type.html#a49f0d5c92128a17fe0c083fc9936de23',1,'Sender::state_type']]]
];
