var searchData=
[
  ['time_5fadvance_39',['time_advance',['../class_receiver.html#aedb53af510b5eec9410a2c416d318e51',1,'Receiver::time_advance()'],['../class_sender.html#ae1b25557826618a8c9908aa1457cbc96',1,'Sender::time_advance()'],['../class_subnet.html#a660dd622ef74c7d4eddc51657943c230',1,'Subnet::time_advance()']]],
  ['timeout_40',['timeout',['../class_sender.html#a4cc4bed733eab96532639b7b1c96b440',1,'Sender']]],
  ['total_5fpacket_5fnum_41',['total_packet_num',['../struct_sender_1_1state__type.html#a74ac5b1aae1490fd31224f664ceb04c8',1,'Sender::state_type']]],
  ['transmiting_42',['transmiting',['../struct_subnet_1_1state__type.html#ac929b69c9d111d22158b5e808f56e8de',1,'Subnet::state_type']]]
];
