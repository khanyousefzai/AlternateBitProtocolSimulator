var searchData=
[
  ['packet_70',['packet',['../struct_subnet_1_1state__type.html#a80bb693ccad684ce2a8dda264e89ca37',1,'Subnet::state_type']]],
  ['packet_5fnum_71',['packet_num',['../struct_sender_1_1state__type.html#aa86380d83a35c10546dfcc75c7c5fa41',1,'Sender::state_type']]],
  ['preparation_5ftime_72',['PREPARATION_TIME',['../class_receiver.html#a547c2b91b5928ef700f291748bd6113b',1,'Receiver::PREPARATION_TIME()'],['../class_sender.html#a9ea18108dc62c27e70e1766d9a3f0775',1,'Sender::PREPARATION_TIME()']]]
];
