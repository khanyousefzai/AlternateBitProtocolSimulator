var searchData=
[
  ['next_5finternal_14',['next_internal',['../struct_sender_1_1state__type.html#a36e3ba9e10bc633e27a4c23403ec03bb',1,'Sender::state_type']]]
];
