var searchData=
[
  ['input_5fports_86',['input_ports',['../class_receiver.html#abce078781615d9bbdd7704de2c06fc15',1,'Receiver::input_ports()'],['../class_sender.html#a2b6fddfe80b75b27ba38ec134fbe8754',1,'Sender::input_ports()'],['../class_subnet.html#a3477f73831589101ea90eda8ca01ae0f',1,'Subnet::input_ports()']]]
];
