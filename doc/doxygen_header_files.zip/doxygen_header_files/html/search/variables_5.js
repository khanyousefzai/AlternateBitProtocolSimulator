var searchData=
[
  ['sending_81',['sending',['../struct_receiver_1_1state__type.html#a07a73a253544ee613b92b04d1bf861f9',1,'Receiver::state_type::sending()'],['../struct_sender_1_1state__type.html#a65ac497dc7469c5561e88ebde16c6bce',1,'Sender::state_type::sending()']]],
  ['state_82',['state',['../class_receiver.html#a0f7134f8b7feeed79accc618b0eafc9c',1,'Receiver::state()'],['../class_sender.html#acf5127a4bd60ef5b5b766dd58e9d90c0',1,'Sender::state()'],['../class_subnet.html#a0867e2f92a7c4ea0c51f5f94d4d825bb',1,'Subnet::state()']]]
];
